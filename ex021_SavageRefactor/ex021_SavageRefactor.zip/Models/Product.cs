// --- Models/Product.cs ---
// TODO: Move Product class here.
// Should include only properties, constructors, and ToString() overrides.

namespace ex021_SavageRefactor.Models
{
    // public class Product { ... }
}
