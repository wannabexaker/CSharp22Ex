// --- Data/DataRepository.cs ---
// Implementation of IDataRepository.
// Handles data retrieval, storage, and updates (in-memory or DB).

namespace ex021_SavageRefactor.Data
{
    // public class DataRepository : IDataRepository
    // {
    //     // private readonly List<Product> _products = new();
    //     // private readonly List<Order> _orders = new();
    //     //
    //     // public Task<List<Product>> GetProductsAsync() => Task.FromResult(_products);
    //     // public Task<List<Order>> GetOrdersAsync() => Task.FromResult(_orders);
    //     // public Task AddOrderAsync(Order order) { _orders.Add(order); return Task.CompletedTask; }
    // }
}
