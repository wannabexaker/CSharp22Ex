// --- Data/IDataRepository.cs ---
// Repository interface for accessing application data.
// Implement this in DataRepository.

namespace ex021_SavageRefactor.Data
{
    // public interface IDataRepository
    // {
    //     Task<List<Product>> GetProductsAsync();
    //     Task<List<Order>> GetOrdersAsync();
    //     Task AddOrderAsync(Order order);
    // }
}
