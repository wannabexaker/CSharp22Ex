// --- Utilities/Extensions.cs ---
// Helper extension methods. Use for LINQ projections, string formatting, etc.

namespace ex021_SavageRefactor.Utilities
{
    // public static class Extensions
    // {
    //     // public static string ToCurrency(this double value) => value.ToString("C2");
    //     // public static IEnumerable<T> SortByName<T>(this IEnumerable<T> source) where T : class
    //     // {
    //     //     // TODO: implement sorting logic
    //     //     // return source;
    //     // }
    // }
}
