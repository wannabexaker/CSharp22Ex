// --- Views/RazorView.cs ---
// Presentation layer (simulated Razor console view).
// Responsible for rendering formatted output only.

namespace ex021_SavageRefactor.Views
{
    // public static class RazorView
    // {
    //     // public static void RenderProductList(IEnumerable<Product> products) { ... }
    //     // public static void RenderOrderDetails(Order order) { ... }
    //     // public static void RenderMessage(string message) { ... }
    // }
}
