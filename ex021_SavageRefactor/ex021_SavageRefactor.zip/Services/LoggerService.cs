// --- Services/LoggerService.cs ---
// Implements ILoggerService. Handles file-based or console logging.

namespace ex021_SavageRefactor.Services
{
    // public class LoggerService : ILoggerService
    // {
    //     // private readonly string _logPath = "app_log.txt";
    //     //
    //     // public void Log(string message)
    //     // {
    //     //     File.AppendAllText(_logPath, $"[{DateTime.Now}] {message}\n");
    //     // }
    //     //
    //     // public async Task LogAsync(string message)
    //     // {
    //     //     await File.AppendAllTextAsync(_logPath, $"[{DateTime.Now}] {message}\n");
    //     // }
    // }
}
