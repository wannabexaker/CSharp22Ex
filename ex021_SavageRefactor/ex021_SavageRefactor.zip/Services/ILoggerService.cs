// --- Services/ILoggerService.cs ---
// Interface for the logger service.
// Keeps the logging abstraction separate from the data or controller logic.

namespace ex021_SavageRefactor.Services
{
    // public interface ILoggerService
    // {
    //     void Log(string message);
    //     Task LogAsync(string message);
    // }
}
